/**
 * Created by 金龙 on 2017/8/24.
 */

({
    baseUrl: 'src/js',
    paths: {
        jquery: 'lib/jquery',
    },
    name: 'main',
    out: 'dist/js/index.merge.min.js'
})