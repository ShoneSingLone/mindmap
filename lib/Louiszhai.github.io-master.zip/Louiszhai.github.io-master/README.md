## 博客

地址：http://louiszhai.github.io

用于梳理前端知识，分享前端技术、个人经验等。

## 招聘

目前我在平安健康，坐标徐汇-龙华中路，公司长期招聘中高级前端工程师，最好两年及以上PC及移动端经验，要求至少熟悉React、Vue、Angular三种 Framework 之一，熟悉webpack、gulp等构建工具，同时前端基础扎实，如果github上有亮点就更好了。简历可以发送到 450383731@qq.com。

## 关于提问

现在博客没有内置默认的评论器，欢迎到 [issue](https://github.com/Louiszhai/Louiszhai.github.io/issues) 中提问。

## 版权

你可以在非商业的前提下免费转载，请务必做到以下两点：

- 文章内容不做修改或补充。
- 注明 `原文作者：路易斯` 及文章链接。